package com.example.api10.navigations

import androidx.navigation.NamedNavArgument

sealed class Destinations ( val ruta :String, val arguments: List<NamedNavArgument>){
    object LoginScreen:Destinations(ruta= "LoginScreen", emptyList())
    object RegistrationScreen: Destinations(ruta = "RegistrationScreen", emptyList())
    object HomeScreen: Destinations(ruta = "HomeScreen" , emptyList())
}