package com.example.api10.presentation.logins

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.navigation.NavController
import com.example.api10.R
import com.example.api10.presentation.components.RoundedButton
import com.example.api10.presentation.components.TransparentTextField


@Composable
fun LoginScreen(
    navController: NavController,
    state: LoginState,
    onLogin : (dato1:String, dato2:String)-> Unit,
    onNavigateToRegister : () -> Unit,
    onDimissDialog: () -> Unit
) {
    val emailValue = rememberSaveable { mutableStateOf("") }
    val passwordValue = rememberSaveable { mutableStateOf("") }
    var passwordVisibility by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        Image(
            modifier = Modifier
                .height(250.dp)
                .width(250.dp),
            painter = painterResource(id = R.drawable.candado),
            contentDescription = "Imagen del logo",
            contentScale = ContentScale.FillBounds
        )
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.BottomCenter
        ) {
            ConstraintLayout {
                val (surface, fab) = createRefs()
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(400.dp)
                        .constrainAs(surface) {
                            bottom.linkTo(parent.bottom)
                        },
                    color = Color.White,
                    shape = RoundedCornerShape(
                        topStartPercent = 8,
                        topEndPercent = 8
                    )
                ) {
                    //buttom of input and password
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Bienvenido",
                            style = MaterialTheme.typography.h4.copy(
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Text(
                            text = "Acceder a la cuenta",
                            style = MaterialTheme.typography.h5.copy(
                                color = MaterialTheme.colors.primary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TransparentTextField(
                                textFieldValue = emailValue,
                                textLabel = "Email",
                                KeyboardType = KeyboardType.Email,
                                KeyboardActions = KeyboardActions (
                                    onNext = {
                                        focusManager.moveFocus(
                                            focusDirection = FocusDirection.Down
                                        )
                                    }
                                ),
                                imeAction = ImeAction.Next
                            )
                            TransparentTextField(
                                textFieldValue = passwordValue,
                                textLabel = "Password",
                                KeyboardType = KeyboardType.Password,
                                KeyboardActions = KeyboardActions(
                                    onDone = {
                                        focusManager.clearFocus()
                                        /*TODO*/
                                    }
                                ),
                                imeAction = ImeAction.Done,
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                            passwordVisibility = !passwordVisibility
                                        }
                                    )
                                    {
                                        Icon(
                                            imageVector = if (passwordVisibility) {
                                                Icons.Default.Visibility
                                            } else {
                                                Icons.Default.VisibilityOff
                                            },
                                            contentDescription = "Toggle"
                                        ) //finIcon
                                    }//finOnclick
                                },//fintrailIcon
                                visualTransformation = if (passwordVisibility) {
                                    VisualTransformation.None
                                } else {
                                    PasswordVisualTransformation()
                                }
                            )//fintextfielContraseña
                            Text(
                                modifier = Modifier
                                    .fillMaxWidth(),
                                text = "has olvidado tu contraseña",
                                style = MaterialTheme.typography.body1,
                                textAlign = TextAlign.End
                            )
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                RoundedButton(
                                    text = "Login",
                                    displayProgressBar = false,
                                    onClick = {
                                        onLogin(emailValue.value, passwordValue.value)
                                    }//finOnclickRounded Button
                                )//Fin roundedButton
                                ClickableText(
                                    text = buildAnnotatedString {
                                        append("no tiene ninguna cuenta activa ")
                                        withStyle(
                                            style = SpanStyle(
                                                color = MaterialTheme.colors.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        ) {
                                            append("Sing Up")
                                        }//finwithStyle
                                    },//Fintext
                                ) {
                                    //TODO
                            }//Fin clickeableTex
                        }//fin columna botones de login
                    }//fin-columna
                }
        }//fin surface
        //add the floatingactionbuttom
        FloatingActionButton(
            modifier = Modifier.size(72.dp),
            backgroundColor = MaterialTheme.colors.primary,
            onClick = { /*TODO*/ })
        {
            Icon(
                modifier = Modifier.size(72.dp),
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "Boton de avanzar",
                tint = Color.White
            )
        }//fin floating
    }//fin-constraint
    }//fin2-box
    }//fin1-box
}//fin-funcion

