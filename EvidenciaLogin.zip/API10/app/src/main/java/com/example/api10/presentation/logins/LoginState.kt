package com.example.api10.presentation.logins

import android.widget.ProgressBar
import androidx.annotation.StringRes
import androidx.compose.compiler.plugins.kotlin.ComposeErrorMessages

data class LoginState(
    val email: String = "",
    val pass : String = "",
    val successLogin : Boolean = false,
    val displayProgressBar: Boolean = false,
    @StringRes val errorMessages: Int? = null
)















