package com.example.api10.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Beige560 = Color(0xfffff2df)
val Green202 = Color(0xff75e900)
val RedFerrari125 = Color(0xFFF44336)
val BlueCharm = Color(0xFF00B0FF)