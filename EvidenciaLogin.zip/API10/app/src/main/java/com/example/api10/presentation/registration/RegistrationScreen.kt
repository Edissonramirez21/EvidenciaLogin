package com.example.api10.presentation.registration


import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.api10.presentation.components.EventDialog
import com.example.api10.presentation.components.RoundedButton
import com.example.api10.presentation.components.SocialMediaButtom
import com.example.api10.presentation.components.TransparentTextField
import androidx.compose.ui.text.input.*
import com.example.api10.navigations.Destinations

@Composable
fun RegistrationScreen(
    navController: NavController,
    state:RegisterState,
    onRegister: (String, String, String, String, String)->Unit,
    onBack:()->Unit,
    onDismissDialog:()->Unit
){
    val nameValue= remember { mutableStateOf("") }
    val emailValue= remember { mutableStateOf("") }
    val phoneValue= remember { mutableStateOf("") }
    val passValue= remember { mutableStateOf("") }
    val confirmPassValue= remember { mutableStateOf("") }

    var passwordVisibility by remember { mutableStateOf(false) }
    var confirmpasswordVisibility by remember { mutableStateOf(false) }

    val focusManager= LocalFocusManager.current
    Box(modifier = Modifier.fillMaxWidth()){
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()))
        {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onBack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription ="Regresar al login" )
                }//FinIconButton
                Text(text = "Crear una Cuenta", style = MaterialTheme.typography.h6.copy(
                    color=MaterialTheme.colors.primary
                ))
            }//FinRow
            Column(modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TransparentTextField(
                    textFieldValue = nameValue,
                    textLabel = "Nombre",
                    KeyboardType = KeyboardType.Text,
                    KeyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//fintransparentFieldNombre
                TransparentTextField(
                    textFieldValue = emailValue,
                    textLabel = "Email",
                    KeyboardType = KeyboardType.Email,
                    KeyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//fintransparentFieldEmail
                TransparentTextField(
                    textFieldValue = phoneValue,
                    textLabel = "Telefono",
                    KeyboardType = KeyboardType.Phone,
                    KeyboardActions =  KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//fintransparentFieldPhone
                TransparentTextField(
                    textFieldValue = passValue,
                    textLabel = "Contraseña",
                    KeyboardType = KeyboardType.Password,
                    KeyboardActions =  KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                    trailingIcon = {
                        IconButton(
                            onClick ={
                                passwordVisibility =! passwordVisibility
                            } //finOnclick
                        ) {
                            Icon(
                                imageVector = if (passwordVisibility) {
                                    Icons.Default.Visibility
                                }else{
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Togle"
                            )//FinIcon
                        }//FinIconButton
                    },//finTrailIcon
                    visualTransformation = if (passwordVisibility){
                        VisualTransformation.None
                    }else{
                        PasswordVisualTransformation()
                    }
                )//fintransparentFieldPass
                TransparentTextField(
                    textFieldValue = confirmPassValue,
                    textLabel = "Confirm Pass",
                    KeyboardType = KeyboardType.Password,
                    KeyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                    trailingIcon = {
                        IconButton(
                            onClick ={
                                passwordVisibility =! passwordVisibility
                            } //finOnclick
                        ) {
                            Icon(
                                imageVector = if (passwordVisibility) {
                                    Icons.Default.Visibility
                                }else{
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Togle"
                            )//FinIcon
                        }//FinIconButton
                    },//finTrailIcon
                    visualTransformation = if (passwordVisibility){
                        VisualTransformation.None
                    }else{
                        PasswordVisualTransformation()
                    }
                )//fintransparentFieldNombre
                Spacer(modifier =Modifier.height(16.dp) )
                RoundedButton(
                    modifier = Modifier.clickable { navController.navigate(route = Destinations.HomeScreen.ruta) },
                    text = "Sing Up",
                    displayProgressBar = state.displayProgressBar,
                    onClick = {  onRegister(
                        nameValue.value,
                        emailValue.value,
                        phoneValue.value,
                        passValue.value,
                        confirmPassValue.value
                    )
                    }
                )//FinRounderButton
                ClickableText(text = buildAnnotatedString {
                    append("Ya tienes una cuenta")
                    withStyle(
                        style= SpanStyle(
                            color=MaterialTheme.colors.primary,
                            fontWeight = FontWeight.Bold
                        )
                    ){
                        append("Log In")
                    }
                },
                    onClick ={
                        onBack()
                    } )
            }//FinColum2
            Spacer(modifier = Modifier.height(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.Gray)
                    Text(modifier = Modifier.padding(8.dp),
                        text = "OR",
                        style = MaterialTheme.typography.h6.copy(fontWeight = FontWeight.Black)
                    )
                    Divider(
                        modifier=Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.Gray)
                }//finROw2
                Text(modifier = Modifier.padding(8.dp),
                    text = "Login With",
                    style = MaterialTheme.typography.body1.copy(MaterialTheme.colors.primary),
                    textAlign = TextAlign.Center
                )
            }//finColum3
            Spacer(modifier = Modifier.height(16.dp))
            Column(modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                SocialMediaButtom(
                    text = "Facebook",
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.secondary)
                SocialMediaButtom(
                    text = "Google",
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.secondaryVariant)
            }
        }//FinColumn
        if (state.errorMessages!=null){
            EventDialog(errorMesage = state.errorMessages, onDismiss = onDismissDialog)
        }
    }//fin del box
}//fin funcion