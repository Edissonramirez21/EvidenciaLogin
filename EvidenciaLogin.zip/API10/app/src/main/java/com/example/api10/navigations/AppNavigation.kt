package com.example.api10.navigations


import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.api10.presentation.logins.LoginScreen
import com.example.api10.presentation.logins.LoginViewModel
import com.example.api10.presentation.registration.RegisterViewMode
import com.example.api10.presentation.registration.RegistrationScreen
import com.example.api10.presentation.screens.HomeScreen




@SuppressLint("SuspiciousIndentation")
@Composable
fun AppNavigation(){
    var conto = rememberNavController()
    NavHost(navController = conto, startDestination = Destinations.LoginScreen.ruta ){
        composable(route = Destinations.LoginScreen.ruta){
            val viewModel=LoginViewModel()
            if(viewModel.state.value.successLogin){
                LaunchedEffect(key1 = Unit ){
                    conto.navigate(Destinations.HomeScreen.ruta ) {
                        popUpTo(Destinations.LoginScreen.ruta){
                            inclusive=true
                        }
                    }
                }
            }else{
                LoginScreen(conto,
                    state = viewModel.state.value,
                    onLogin = viewModel::login,
                    //onDismissDialog = viewModel::hideErrorDialog,
                    onNavigateToRegister = { conto.navigate(Destinations.RegistrationScreen.ruta)}
                )
            }

        }

        composable(
            route = Destinations.RegistrationScreen.ruta + "/{email}" + "/{pass}",
        arguments = Destinations.HomeScreen.arguments
        ) { backStackEntry ->
            val email3 = backStackEntry.arguments?.getString("email") ?: ""
            val pass3 = backStackEntry.arguments?.getString("pass") ?: ""

        }


            val viewModel=RegisterViewMode()
        composable(Destinations.RegistrationScreen.ruta) {
            RegistrationScreen(
                conto,
                state =  viewModel.state.value,
                onRegister = viewModel::registerr,
                onBack = {conto.popBackStack()},
                onDismissDialog =viewModel::hideErrorDialog)
        }
        composable(route = Destinations.HomeScreen.ruta){ HomeScreen(conto) }
    }
}//finFuncion